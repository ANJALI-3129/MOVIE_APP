// src/api/tmdb.js

const API_KEY = process.env.REACT_APP_TMDB_API_KEY;
const BASE_URL = process.env.REACT_APP_TMDB_BASE_URL;
const fetchMovies = async (
  endpoint,
  genreMap,
  pages = 1,
  defaultMediaType = null,
) => {
  const allMovies = [];

  for (let page = 1; page <= pages; page++) {
    const separator = endpoint.includes("?") ? "&" : "?";

    const res = await fetch(
      `${BASE_URL}${endpoint}${separator}api_key=${API_KEY}&page=${page}`,
    );

    const data = await res.json();

    allMovies.push(
      ...data.results.map((movie) =>
        formatMovie(movie, genreMap, defaultMediaType),
      ),
    );
  }

  // Remove duplicate movies
  return Array.from(
    new Map(allMovies.map((movie) => [movie.id, movie])).values(),
  );
};

export const getPopularMovies = (generMap) => {
  return fetchMovies("/movie/popular", generMap, 3, "movie");
};
export const getTrendingMovies = (generMap) => {
  return fetchMovies("/trending/all/week", generMap, 1, null);
};
export const getTVShows = (generMap) => {
  return fetchMovies("/tv/popular", generMap, 3, "tv");
};

// api.js

export const getTopRatedMovies = (genreMap) => {
  return fetchMovies("/movie/top_rated", genreMap, 3, "movie");
};

export const getUpcomingMovies = (genreMap) => {
  return fetchMovies("/movie/upcoming", genreMap, 3, "movie");
};

export const getHollywoodMovies = (genreMap) => {
  return fetchMovies(
    "/discover/movie?with_original_language=en&sort_by=vote_average.desc&vote_count.gte=500",
    genreMap,
    3,
    "movie",
  );
};

export const getBollywoodMovies = (genreMap) => {
  return fetchMovies(
    "/discover/movie?with_original_language=hi&sort_by=popularity.desc",
    genreMap,
    3,
    "movie",
  );
};
export const getGenres = async () => {
  const res = await fetch(`${BASE_URL}/genre/movie/list?api_key=${API_KEY}`);

  const data = await res.json();

  const map = {};
  data.genres.forEach((g) => {
    map[g.id] = g.name;
  });

  return map;
};

export const getDetails = async (type, id) => {
  const res = await fetch(`${BASE_URL}/${type}/${id}?api_key=${API_KEY}`);

  return await res.json();
};

export const formatMovie = (movie, genreMap, defaultMedia) => ({
  id: movie.id,
  mediaType: movie.media_type || defaultMedia,
  title: movie.title || movie.name,
  name: movie.name,
  plot: movie.overview,
  rating: movie.vote_average?.toFixed(1) || "N/A",

  poster: movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : "https://via.placeholder.com/500",

  backdrop: movie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
    : null,

  es: movie.genres
    ? movie.genres.map((g) => g.name)
    : movie.genre_ids?.map((id) => genreMap?.[id] || "Unknown") || [],

  isInCart: false,
});
