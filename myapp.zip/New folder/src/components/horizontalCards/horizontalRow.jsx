import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./horizontalRow.css";

const API_KEY = process.env.REACT_APP_TMDB_API_KEY;

function HorizontalRow({ title, endpoint, viewAll }) {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
  

  const fetchMovies = async () => {
    try {
    const separator = endpoint.includes("?") ? "&" : "?";

const res = await fetch(
  `https://api.themoviedb.org/3/${endpoint}${separator}api_key=${API_KEY}`
);

      const data = await res.json();
      setMovies(data.results.slice(0, 10));
    } catch (err) {
      console.error(err);
    }
  }
    fetchMovies();
  }, [endpoint]);

  return (
    <section className="row-section">
      <div className="row-header">
        <h2>{title}</h2>

        <Link to={viewAll} className="view-all">
          View All →
        </Link>
      </div>

      <div className="Hori-movie-row">
        {movies.map((movie) => (
          <Link
            key={movie.id}
            to={`/movie/${movie.id}`}
            className="Hori-movieCard"
          >
            <img
              src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
              alt={movie.title || movie.name}
            />

            <p>{movie.title || movie.name}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default HorizontalRow;