
import "./navbar.css";
// import SearchBar from "../searchBar/searchBar";
import { auth } from "../../firebase";
import { useNavigate } from "react-router-dom";
import { signOut } from "firebase/auth";
import { useState } from "react";


const Navbar = ({ cartCount, user,setCategories }) => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen]=useState(false);


  const handleLogout = async () => {
    try {
      await signOut(auth);
navigate("/");
    }
    catch(error)
    {
console.log("error");
    }
  };

  const getInitials = (email) => {
    if (!email) return "U";
    return email.slice(0, 2).toUpperCase();
  };


  return (
    <div className="nav">
     <div className="head">

  <div className="logo" onClick={() => navigate("/")}>
    Movix
  </div>

  {/* Hamburger */}
  <div
    className="menu-toggle"
    onClick={() => setMenuOpen(!menuOpen)}
  >
    ☰
  </div>

  {/* Navigation */}
  <ul className={menuOpen ? "Movie active" : "Movie"}>
    <li onClick={() => navigate("/movies/trending")}>
      Trending Movies
    </li>

    <li onClick={() => navigate("/movies/popular")}>
      Popular Movies
    </li>

    <li onClick={() => navigate("/movies/tv")}>
      TV Shows
    </li>
  </ul>

  <div className="right-section">

    <div
      className="cart-icon"
      onClick={() => navigate("/watchlist")}
    >
      <i className="fa-solid fa-bookmark"></i>
      <span className="cart-count">{cartCount}</span>
    </div>

    {!user ? (
      <button onClick={() => navigate("/login")}>
        Login
      </button>
    ) : (
      <div className="user-section">
        <button onClick={handleLogout}>
          Logout
        </button>

        <div className="avatar">
          {getInitials(user.email)}
        </div>
      </div>
    )}

  </div>

</div>
    </div>
  );
};

export default Navbar;