import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

export const loadUserData = async (uid) => {
  try {
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);

    if (snap.exists()) {
      return snap.data().cart?.length || 0;
    } else {
      await setDoc(ref, { cart: [] });
      return [];
    }
  } catch (err) {
    console.error(err);
    return [];
  }
};

export const syncMovies = async (movies, uid) => {
  if (!uid) return movies;
  try {
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) return movies;
    const cart = snap.data().cart || [];
    return movies.map((movie) => ({
      ...movie,
      isInCart: cart.includes(movie.id),
    }));
  } catch (err) {
    console.log(err);
    return movies;
  }
};

export const updateCart = async (uid, movieId, isAdding) => {
  const ref = doc(db, "users", uid);
  const snap = await getDoc(ref);
  let cart = snap.data()?.cart || [];
  if (isAdding) {
    cart.push(movieId);
  } else {
    cart = cart.filter((id) => id !== movieId);
  }
  await updateDoc(ref, { cart });
  return cart;
};
