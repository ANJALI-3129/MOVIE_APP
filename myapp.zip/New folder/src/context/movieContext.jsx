 useEffect(() => {
    init(user);
  }, [categories, user]);

  const init = async (firebaseUser) => {
    try {
      genreMapRef.current = await getGenres();

      let fetchedMovies = [];
      if (categories === "popular") {
        fetchedMovies = await getPopularMovies(genreMapRef.current);
      } else if (categories === "trending") {
        fetchedMovies = await getTrendingMovies(genreMapRef.current);
      } else if (categories === "tv") {
        fetchedMovies = await getTVShows(genreMapRef.current);
      }

      const synced = await syncMovies(fetchedMovies, firebaseUser?.uid);

      setMovies(synced);

      if (synced.length > 0) {
        const randomMovie = synced[Math.floor(Math.random() * synced.length)];

        setBackground(randomMovie.backdrop);
      }
      setLoading(false);
      console.log("Category:", categories);
      console.log("Fetched:", fetchedMovies);
      console.log("Is Array:", Array.isArray(synced));
    } catch (err) {
      console.error("Init Error:", err);
      setLoading(false);
    }
  };