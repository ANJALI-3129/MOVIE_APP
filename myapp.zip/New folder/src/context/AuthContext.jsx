
 const [user, setUser] = useState(null);
useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        const cart = await loadUserData(firebaseUser.uid);
        setCartCount(cart.length);
      } else {
        setUser(null);
        setCartCount(0);
      }
    });

    return () => unsubscribe();
  }, []);
