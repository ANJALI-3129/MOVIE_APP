import { useState, useEffect } from "react";
import MovieList from "../../components/movielist/movieList";
import {getPopularMovies, getTrendingMovies, getTVShows,
  getGenres,getBollywoodMovies,getHollywoodMovies,getTopRatedMovies, getUpcomingMovies
} from "../../API/api";


import { useParams } from "react-router-dom";

const MoviesPage=({toggleCart})=> {


    const { category } = useParams();

    const [movies, setMovies] = useState([]);

   

useEffect(() => {
  async function loadMovies() {
    try {
      const genreMap = await getGenres();
      let data = [];

      if (category === "popular") {
        data = await getPopularMovies(genreMap);
      } else if (category === "trending") {
        data = await getTrendingMovies(genreMap);
      } else if (category === "tv") {
        data = await getTVShows(genreMap);
      } else if (category === "top_rated") {
        data = await getTopRatedMovies(genreMap);
      } else if (category === "upcoming") {
        data = await getUpcomingMovies(genreMap);
      } else if (category === "hollywood") {
        data = await getHollywoodMovies(genreMap);
      } else if (category === "bollywood") {
        data = await getBollywoodMovies(genreMap);
      }

      setMovies(data);
    } catch (err) {
      console.error(err);
    }
  }

  loadMovies();
}, [category]);

 
  return (
    <MovieList
            movies={movies}
            categories={category}
            toggleCart={toggleCart}
        />
  );
}
export default MoviesPage;