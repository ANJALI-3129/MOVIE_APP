import { useEffect, useState } from "react";
import "./watchlist.css";
import {formatMovie} from "../../API/api"
import { db, auth } from "../../firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import MovieCard from "../../components/moviecard/movieCard";

const API_KEY = process.env.REACT_APP_TMDB_API_KEY;
const BASE_URL = process.env.REACT_APP_TMDB_BASE_URL;

const Watchlist = ({ setCartCount }) => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
        fetchWatchlist(user);
      } else {
        setCurrentUser(null);
        setMovies([]);
      
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const fetchWatchlist = async (user) => {
    try {
      const ref = doc(db, "users", user.uid);
      const snap = await getDoc(ref);
      const cart = snap.data()?.cart || [];

      const moviePromises = cart.map((id) =>
        fetch(`${BASE_URL}/movie/${id}?api_key=${API_KEY}`).then((res) =>
          res.json()
        )
      );

      const results = await Promise.all(moviePromises);

     const formatted = results.map(movie => ({
    ...formatMovie(movie, {}, "movie"),
    isInCart: true,
}));
  console.log(formatted)
      setMovies(formatted);
    } catch (err) {
      console.error("Watchlist Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveFromCart = async (movie) => {
    if (!currentUser) return;

    try {
      const ref = doc(db, "users", currentUser.uid);
      const snap = await getDoc(ref);
      const cart = snap.data()?.cart || [];

      const updatedCart = cart.filter((id) => id !== movie.id);
  await updateDoc(ref, { cart: updatedCart });

setMovies((prev) => prev.filter((m) => m.id !== movie.id));

setCartCount(updatedCart.length);
    } catch (err) {
      console.error("Remove Error:", err);
    }
  };

  if (loading) return <h2 className="status">Loading...</h2>;

  return (
    <div className="watchlist-page">
      <h1>Your Watchlist</h1>

      {movies.length === 0 ? (
        <p className="status">No movies added yet</p>
      ) : (
        <div className="watchlist-grid">
          {movies.map((movie) => (
            <MovieCard
              key={movie.id}
              movies={movie}
              toggleCart={handleRemoveFromCart}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Watchlist;
