import { useState, useEffect, useRef } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Watchlist from "./pages/watchlist/watchlist";
import Navbar from "./components/Navbar/navbar";
import Home from "./pages/homepage/home";
import Loader from "./components/Loader/loader";
import MovieDetails from "./pages/movieDetails/movieDetails";
import Login from "./pages/login/login";
import MoviePage from "./pages/movies/moviepage";
import Footer from "./components/footer/footer";
import { auth } from "./firebase";
import { onAuthStateChanged } from "firebase/auth";
import {
  getGenres,
  getPopularMovies,
  getTrendingMovies,
  getTVShows,
} from "./API/api";
import {
  loadUserData,
  syncMovies,
  updateCart,
} from "./services/firebaseService";
import "./index.css";
import ProtectedRoute from "./components/protectedroute/protectedRoute";

const App = () => {
  const [loading, setLoading] = useState(true);
  const [movies, setMovies] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const [user, setUser] = useState(null);
  const [categories, setCategories] = useState("popular");
  const [background, setBackground] = useState("");
  const navigate = useNavigate();
  const genreMapRef = useRef({});

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        const cart = await loadUserData(firebaseUser.uid);
        setCartCount(cart.length);
      } else {
        setUser(null);
        setCartCount(0);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    init(user);
  }, [categories, user]);

  const init = async (firebaseUser) => {
    try {
      genreMapRef.current = await getGenres();

      let fetchedMovies = [];
      if (categories === "popular") {
        fetchedMovies = await getPopularMovies(genreMapRef.current);
      } else if (categories === "trending") {
        fetchedMovies = await getTrendingMovies(genreMapRef.current);
      } else if (categories === "tv") {
        fetchedMovies = await getTVShows(genreMapRef.current);
      }

      const synced = await syncMovies(fetchedMovies, firebaseUser?.uid);

      setMovies(synced);

      if (synced.length > 0) {
        const randomMovie = synced[Math.floor(Math.random() * synced.length)];

        setBackground(randomMovie.backdrop);
      }
      setLoading(false);
      console.log("Category:", categories);
      console.log("Fetched:", fetchedMovies);
      console.log("Is Array:", Array.isArray(synced));
    } catch (err) {
      console.error("Init Error:", err);
      setLoading(false);
    }
  };

  const handleAddToCart = async (movie) => {
    if (!user) {
      navigate("/login");

      return;
    }

    const updatedMovies = movies.map((m) =>
      m.id === movie.id ? { ...m, isInCart: !m.isInCart } : m,
    );

    const selectedMovie = updatedMovies.find((m) => m.id === movie.id);

    const cart = await updateCart(
      user.uid,

      movie.id,

      selectedMovie.isInCart,
    );

    setMovies(updatedMovies);

    setCartCount(cart.length);
  };
  return (
    <>
      <Navbar cartCount={cartCount} user={user} setCategories={setCategories} />

      <Routes>
        <Route
          path="/"
          element={
            loading ? (
              <Loader />
            ) : (
              <Home
                movies={movies}
                background={background}
                setCategories={setCategories}
              />
            )
          }
        />
        <Route path="/login" element={<Login background={background} />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
        <Route path="/tv/:id" element={<MovieDetails />} />
        <Route
          path="/movies/:category"
          element={
            <MoviePage toggleCart={handleAddToCart} categories={categories} />
          }
        />
        <Route
          path="/watchlist"
          element={
            <ProtectedRoute>
              <Watchlist cartCount={cartCount} setCartCount={setCartCount} />
            </ProtectedRoute>
          }
        />
      </Routes>
      <Footer />
    </>
  );
};

export default App;
